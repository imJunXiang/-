#include "cacheflush.h"

@implementation Super
+(void)initialize { } 
+class { return self; }
+(int)classMethod { return 1; }
-(int)instanceMethod { return 1; }
@end
