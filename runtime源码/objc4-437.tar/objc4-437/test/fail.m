#include "test.h"

int main()
{
    fail("always fails");
}
